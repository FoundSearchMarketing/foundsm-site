import blogPost from './blogPost';
import blogCategory from './blogCategory';
import author from './author';
import teamMember from './teamMember';
import landingPage from './landingPage';
import heroBlock from './blocks/heroBlock';
import statsBlock from './blocks/statsBlock';
import featuresBlock from './blocks/featuresBlock';
import testimonialBlock from './blocks/testimonialBlock';
import ctaBlock from './blocks/ctaBlock';
import formBlock from './blocks/formBlock';
import textBlock from './blocks/textBlock';
import imageTextBlock from './blocks/imageTextBlock';
import logoBarBlock from './blocks/logoBarBlock';
import faqBlock from './blocks/faqBlock';

export const schemaTypes = [
  blogPost,
  blogCategory,
  author,
  teamMember,
  landingPage,
  heroBlock,
  statsBlock,
  featuresBlock,
  testimonialBlock,
  ctaBlock,
  formBlock,
  textBlock,
  imageTextBlock,
  logoBarBlock,
  faqBlock,
];
